import 'package:flutter/material.dart';

// --- DEFINISI WARNA ---
class AppColors {
  static const Color background = Color(0xFFF7F7F0); 
  static const Color primaryOlive = Color(0xFF6C8C4E); 
  static const Color darkOlive = Color(0xFF4A6038); 
  static const Color mustardYellow = Color(0xFFEAA61E); 
  static const Color lightGreen = Color(0xFFA6C38A); 
  static const Color textDark = Color(0xFF333333);
}

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi Konsultasi Mental',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primaryOlive,
          primary: AppColors.primaryOlive,
          secondary: AppColors.mustardYellow,
          background: AppColors.background,
        ),
        scaffoldBackgroundColor: AppColors.background,
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const HomePage(),
        '/article': (context) => const ArticlePage(),
        '/booking': (context) => const BookingPage(),
      },
    );
  }
}

// ====================================================================
// --- HALAMAN 1: HOME PAGE ---
// ====================================================================

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  // Widget untuk Chip Kategori di bagian atas (SUDAH BISA DIKLIK)
  Widget _buildCategoryChip(String label, {bool isSelected = false}) {
    return GestureDetector(
      onTap: () {
        // Aksi: Mencetak ke konsol sebagai simulasi filter
        print('Kategori $label diklik.');
      },
      child: Container(
        margin: const EdgeInsets.only(right: 8.0),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.mustardYellow : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? AppColors.mustardYellow : Colors.grey.shade200,
          ),
          boxShadow: [
            if (isSelected)
              BoxShadow(
                color: AppColors.mustardYellow.withOpacity(0.3),
                blurRadius: 5,
                offset: const Offset(0, 2),
              ),
          ],
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? AppColors.textDark : AppColors.textDark,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  // Widget untuk Kartu Topik Utama (Career/Relationship)
  Widget _buildTopicCard(String title, IconData icon, Color backgroundColor) {
    return Container(
      width: 170, // Lebar disesuaikan
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: backgroundColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: backgroundColor,
              size: 24,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: TextStyle(
              color: AppColors.textDark,
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  // Widget untuk Kartu Konten (About a panic attack)
  Widget _buildContentCard(
      BuildContext context, String title, String subtitle, Color color1, Color color2) {
    return GestureDetector(
      onTap: () {
        // AKSI: Pindah ke ArticlePage
        Navigator.pushNamed(context, '/article');
      },
      child: Container(
        width: MediaQuery.of(context).size.width / 2 - 20, // Setengah lebar layar - padding
        height: 180,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: [color1, color2],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: color1.withOpacity(0.4),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            // Simplified Pattern
            Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            Text(
              subtitle,
              style: TextStyle(
                color: Colors.white.withOpacity(0.8),
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Tambahkan Builder untuk memungkinkan Scaffold.of(context) bekerja
      body: Builder(
        builder: (context) {
          return SingleChildScrollView(
            padding: const EdgeInsets.only(top: 50.0, left: 20, right: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // HEADER (Profile, Nama, Menu)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        // Avatar dengan Foto Profil
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.grey.shade300,
                            // --- PERBAIKAN: Memuat asset gambar
                            image: const DecorationImage(
                              image: AssetImage('assets/images/my_profile.jpg'),
                              fit: BoxFit.cover,
                            ),
                            // ------------------------------------
                          ),
                        ),
                        const SizedBox(width: 10),
                      ],
                    ),
                    // Tombol Menu Kanan Atas (Titik Tiga) (SUDAH BISA DIKLIK)
                    IconButton(
                      icon: const Icon(Icons.menu_rounded, size: 30),
                      onPressed: () {
                        // AKSI: Membuka EndDrawer (menu samping kanan)
                        Scaffold.of(context).openEndDrawer(); 
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // NAMA PENGGUNA DAN NIM
                const Text(
                  'Halo,',
                  style: TextStyle(
                    color: AppColors.textDark,
                    fontSize: 24,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const Text(
                  'Rifki Hasbhi Fauji',
                  style: TextStyle(
                    color: AppColors.textDark,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Text(
                  'NIM: 232101358',
                  style: TextStyle(
                    color: AppColors.primaryOlive,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 25),

                // SEARCH BAR
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.shade200,
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: const TextField(
                    decoration: InputDecoration(
                      hintText: 'Search',
                      border: InputBorder.none,
                      icon: Icon(Icons.search, color: Colors.grey),
                    ),
                  ),
                ),
                const SizedBox(height: 25),

                // KATEGORI CHIPS (SUDAH BISA DIKLIK)
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildCategoryChip('For you', isSelected: true),
                      _buildCategoryChip('Relationships'),
                      _buildCategoryChip('Parenting'),
                      _buildCategoryChip('Stress'),
                      _buildCategoryChip('Motivation'),
                    ],
                  ),
                ),
                const SizedBox(height: 25),

                // KARTU TOPIK
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildTopicCard(
                        'Career motivation',
                        Icons.star_border_rounded,
                        AppColors.mustardYellow,
                      ),
                      const SizedBox(width: 15),
                      _buildTopicCard(
                        'Relationship with parents',
                        Icons.home_outlined,
                        AppColors.primaryOlive,
                      ),
                      const SizedBox(width: 15),
                      _buildTopicCard(
                        'Self-Confidence',
                        Icons.favorite_border,
                        Colors.red,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 25),

                // KARTU KONTEN
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildContentCard(
                      context,
                      'About a panic attack',
                      'How does it nourish itself',
                      AppColors.primaryOlive,
                      AppColors.lightGreen,
                    ),
                    _buildContentCard(
                      context,
                      'What to do if the future scares',
                      'The four-screen method',
                      AppColors.mustardYellow,
                      const Color(0xFFF7C356), // Warna kuning yang lebih terang
                    ),
                  ],
                ),
                const SizedBox(height: 80), // Ruang untuk Bottom Nav
              ],
            ),
          );
        }
      ),

      // END DRAWER (Diperlukan agar tombol menu kanan atas berfungsi)
      endDrawer: const Drawer(
        child: Center(
          child: Text('Menu Samping'),
        ),
      ),

      // BOTTOM NAVIGATION BAR (SEMUA IKON SUDAH BISA DIKLIK DAN NAVIGASI)
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
        margin: const EdgeInsets.only(bottom: 10, left: 20, right: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade300,
              blurRadius: 15,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Row( 
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Tombol Home
            IconButton(
                icon: const Icon(Icons.home_filled, color: AppColors.primaryOlive),
                onPressed: () {
                  // Aksi: Kembali ke halaman utama (jika sudah di Home)
                }), 
            
            // Tombol Calendar/Booking (AKSI: Pindah ke BookingPage)
            IconButton(
                icon: const Icon(Icons.calendar_today_outlined, color: Colors.grey),
                onPressed: () {
                  Navigator.pushNamed(context, '/booking'); 
                }),
            
            // Tombol Forum (AKSI: Pindah ke BookingPage untuk simulasi)
            IconButton(
                icon: const Icon(Icons.forum_outlined, color: Colors.grey),
                onPressed: () {
                   Navigator.pushNamed(context, '/booking'); 
                }),
            
            // Tombol Profile (AKSI: Pindah ke BookingPage untuk simulasi)
            IconButton(
                icon: const Icon(Icons.person_outline, color: Colors.grey),
                onPressed: () {
                   Navigator.pushNamed(context, '/booking'); 
                }),
          ],
        ),
      ),
    );
  }
}

// ====================================================================
// --- HALAMAN 2: ARTICLE PAGE ---
// ====================================================================

class ArticlePage extends StatelessWidget {
  const ArticlePage({super.key});

  // Widget untuk Kartu Bagian (Breathing Exercises)
  Widget _buildSectionCard(String title, String subtitle) {
    return GestureDetector( // Ditambahkan GestureDetector agar kartu bisa diklik
      onTap: () {
        print('Section $title diklik!');
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade200,
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.textDark,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.mustardYellow,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.keyboard_arrow_right,
                  color: Colors.white, size: 20),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.8),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.arrow_back_ios_new,
                color: AppColors.textDark, size: 20),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          // Pattern Header (Simplified)
          Container(
            height: 250,
            decoration: const BoxDecoration(
              color: AppColors.lightGreen, 
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: const CustomPaint(
              size: Size(double.infinity, 250),
              painter: PatternPainter(), 
            ),
          ),
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 220), 

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Judul
                      const Text(
                        'About a panic attack',
                        style: TextStyle(
                          color: AppColors.textDark,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'How does it nourish itself',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Konten Utama
                      Container( 
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: const BorderRadius.all(Radius.circular(20)),
                          boxShadow: [
                            BoxShadow( 
                              color: Colors.grey,
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Text(
                          'A panic attack is an attack of acute fear, horror, and a mixture of otherworldly feeling. Perform breathing exercises and make an appointment with a psychologist.',
                          style: TextStyle(
                            color: AppColors.textDark,
                            fontSize: 15,
                            height: 1.5,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Kartu Bagian
                      _buildSectionCard(
                        'Breathing exercises',
                        'Effective, harmless ways to relieve stress',
                      ),
                      const SizedBox(height: 20),
                      // Contoh Kartu Bagian Lain
                      _buildSectionCard(
                        'Deep Sleep Protocol',
                        'Techniques for restorative rest',
                      ),
                      const SizedBox(height: 100), 
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      // Bottom Button (Booking consultation) (SUDAH BISA DIKLIK)
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(bottom: 25.0, left: 20, right: 20),
        child: ElevatedButton(
          onPressed: () {
            // AKSI: Pindah ke BookingPage
            Navigator.pushNamed(context, '/booking');
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryOlive,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(25),
            ),
            padding: const EdgeInsets.symmetric(vertical: 16),
            elevation: 5,
          ),
          child: const Text(
            'Booking consultation',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}

// Custom Painter untuk meniru pola geometris di header
class PatternPainter extends CustomPainter {
  const PatternPainter(); 

  @override
  void paint(Canvas canvas, Size size) {
    final yellowPaint = Paint()..color = AppColors.mustardYellow;
    final darkOlivePaint = Paint()..color = AppColors.darkOlive;

    // Kuning di kanan atas
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * 0.5, 0, size.width * 0.6, size.height * 0.4),
        const Radius.circular(20),
      ),
      yellowPaint,
    );

    // Hijau Tua di kiri atas
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.width * 0.6, size.height * 0.6),
        const Radius.circular(20),
      ),
      darkOlivePaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ====================================================================
// --- HALAMAN 3: BOOKING PAGE ---
// ====================================================================

class BookingPage extends StatelessWidget {
  const BookingPage({super.key});

  // Widget untuk Kartu Spesialis
  Widget _buildSpecialistCard(String name, String experience, String imageUrl,
      {bool isSelected = false}) {
    return Container(
      width: 150,
      padding: const EdgeInsets.all(8),
      margin: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        color: isSelected ? AppColors.primaryOlive : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Avatar Placeholder
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.grey.shade300,
              image: DecorationImage(
                image: NetworkImage(imageUrl),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    color: isSelected ? Colors.white : AppColors.textDark,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  experience,
                  style: TextStyle(
                    color: isSelected ? Colors.white.withOpacity(0.8) : Colors.grey.shade600,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Widget untuk Chip Waktu
  Widget _buildTimeChip(String time, {bool isSelected = false}) {
    return Container(
      margin: const EdgeInsets.only(right: 10, bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: isSelected ? AppColors.mustardYellow : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected ? AppColors.mustardYellow : Colors.grey.shade300,
          width: 1,
        ),
      ),
      child: Text(
        time,
        style: TextStyle(
          color: isSelected ? Colors.white : AppColors.textDark,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
          fontSize: 14,
        ),
      ),
    );
  }

  // Data hari dalam seminggu
  final List<String> daysOfWeek = const ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
  // Data tanggal untuk bulan Juni 2022
  final List<String?> dates = const [
    null,
    null,
    null,
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
    '11',
    '12',
    '13',
    '14',
    '15',
    '16',
    '17',
    '18',
    '19',
    '20',
    '21',
    '22',
    '23',
    '24',
    '25',
    '26',
    '27',
    '28',
    '29',
    '30',
  ];

  // Helper untuk menentukan apakah tanggal adalah tanggal yang dipilih (meniru foto)
  bool _isDateSelected(String? date) {
    return date == '14' || date == '15' || date == '16' || date == '18' || date == '25';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: AppColors.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Booking consultation',
          style: TextStyle(
            color: AppColors.textDark,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Text(
                'Our specialists',
                style: TextStyle(
                  color: AppColors.textDark,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
            const SizedBox(height: 15),

            // Spesialis Cards
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Row(
                children: [
                  _buildSpecialistCard(
                    'Lory Ford',
                    '3 years of experience',
                    'https://placehold.co/100x100/EAA61E/FFFFFF?text=LF',
                    isSelected: false,
                  ),
                  _buildSpecialistCard(
                    'Kate Carter',
                    '7 years of experience',
                    'https://placehold.co/100x100/6C8C4E/FFFFFF?text=KC',
                    isSelected: true,
                  ),
                  _buildSpecialistCard(
                    'Rifki Hasbhi',
                    'NIM 232101358',
                    'https://placehold.co/100x100/4A6038/FFFFFF?text=RH',
                    isSelected: false,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 25),

            // Kalender Section
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20.0),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.primaryOlive,
                borderRadius: BorderRadius.circular(25),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryOlive.withOpacity(0.4),
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header Bulan
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'June 2022',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      Row(
                        children: [
                          Icon(Icons.arrow_back_ios,
                              color: Colors.white.withOpacity(0.7), size: 16),
                          const SizedBox(width: 10),
                          const Icon(Icons.arrow_forward_ios,
                              color: Colors.white, size: 16),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Kalender Grid
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 7,
                      mainAxisSpacing: 15,
                      crossAxisSpacing: 5,
                    ),
                    itemCount: daysOfWeek.length + dates.length,
                    itemBuilder: (context, index) {
                      if (index < daysOfWeek.length) {
                        // Days of Week
                        return Center(
                          child: Text(
                            daysOfWeek[index],
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        );
                      } else {
                        // Dates
                        final dateIndex = index - daysOfWeek.length;
                        final date = dates[dateIndex];
                        final isToday = date == '17'; // Meniru foto
                        final isSelected = _isDateSelected(date);
                        final isRange = date == '14' || date == '15' || date == '16';

                        if (date == null) return Container();

                        return Stack(
                          alignment: Alignment.center,
                          children: [
                            if (isRange)
                              Positioned.fill(
                                left: date == '14' ? 0 : -8, // Menutupi gap
                                right: date == '16' ? 0 : -8,
                                child: Container(
                                  margin: EdgeInsets.symmetric(
                                      vertical: 5, horizontal: date == '15' ? 0 : 8),
                                  decoration: BoxDecoration(
                                    color: AppColors.mustardYellow.withOpacity(0.5),
                                    borderRadius: BorderRadius.horizontal(
                                      left: date == '14'
                                          ? const Radius.circular(10)
                                          : Radius.zero,
                                      right: date == '16'
                                          ? const Radius.circular(10)
                                          : Radius.zero,
                                    ),
                                  ),
                                ),
                              ),
                            Container(
                              width: 35,
                              height: 35,
                              decoration: BoxDecoration(
                                color: isToday ? Colors.white : Colors.transparent,
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: Text(
                                  date,
                                  style: TextStyle(
                                    color: isToday
                                        ? AppColors.textDark
                                        : isSelected
                                            ? AppColors.mustardYellow
                                            : Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        );
                      }
                    },
                  ),

                  const SizedBox(height: 30),
                  const Text(
                    'Select time',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 15),

                  // Time Chips
                  Wrap(
                    children: [
                      _buildTimeChip('9:00 AM', isSelected: true),
                      _buildTimeChip('10:00 AM'),
                      _buildTimeChip('11:00 AM'),
                      _buildTimeChip('12:00 PM'),
                      _buildTimeChip('1:00 PM'),
                      _buildTimeChip('2:00 PM'),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // Booking Button (di dalam container hijau)
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        // Logic booking
                        print('Final booking diklik');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.darkOlive,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        elevation: 0,
                      ),
                      child: const Text(
                        'Booking',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 50),
          ],
        ),
      ),
    );
  }
}